# tic_tac_toe
A Simple Tic Tac Toe Game written in python3 with the help of Tkinter. 
The best thing? It's completely Dynamic! All you gotta do is change the value of App(N)!!

<img src="ss.png">
<img src="ss_1.png">
<img src="ss_2.png">
